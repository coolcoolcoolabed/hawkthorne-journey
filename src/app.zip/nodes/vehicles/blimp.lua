return{
  name= 'blimp',
  type= 'vehicle',
  hasAttack = true,
  move = {'once', {'1,1'}, .1},
  attack = {'once', {'1,1'}, .1},
  height = 206,
  width = 199,
  xOffset= 67,
  yOffset= 156,
}
