return{
  name= 'golfcart',
  type= 'vehicle',
  height = 39,
  width = 56,
  xOffset = -8,
  yOffset = -43,
  move = {'loop',{'1-2,1'},0.25},
}
