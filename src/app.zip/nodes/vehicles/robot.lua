return{
  name= 'robot',
  type= 'vehicle',
  hasAttack = true,
  move = {'loop', {'2,1','1,1','3,1','1,1'}, .25},
  attack = {'loop', {'1-3,1'}, .25},
  height = 223,
  width = 216,
  xOffset= 40,
  yOffset= -17,
}
