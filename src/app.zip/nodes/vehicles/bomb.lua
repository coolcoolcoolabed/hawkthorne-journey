return{
  name= 'bomb',
  type= 'vehicle',
  hasAttack = true,
  move = {'once', {'1,1'}, .1},
  attack = {'once', {'1,1'}, .1},
  height = 201,
  width = 423,
  xOffset= 290,
  yOffset= -30,
}
