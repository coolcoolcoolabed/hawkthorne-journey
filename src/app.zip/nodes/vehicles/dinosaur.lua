return{
  name= 'dinosaur',
  type= 'vehicle',
  hasAttack = true,
  move = {'loop', {'1,3','1,1','1,4','1,1'}, .25},
  attack = {'once', {'1,2'}, .10},
  height = 194,
  width = 324,
  xOffset= 145,
  yOffset= -9,
}
