return{
  name= 'claypot',
  type= 'throwable',
  explode= {
    frameWidth = 41,
    frameHeight = 30,
    animation = {'once', {'1-5,1'}, .10},
  },
  bothHands = true,
}
