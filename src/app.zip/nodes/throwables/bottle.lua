return{
  name= 'bottle',
  type= 'throwable',
  explode= {
    frameWidth = 7,
    frameHeight = 15,
    animation = {'once', {'1-5,1'}, .10},
  },
  height = 15,
  width = 7,
}
