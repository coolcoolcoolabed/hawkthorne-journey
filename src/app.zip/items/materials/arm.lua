return{
  name = 'arm',
  description = 'Arm',
  type = 'material',
  info = 'a human arm',
  MAX_ITEMS = 10,
}
