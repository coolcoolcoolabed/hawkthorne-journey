return{
  name = 'stick',
  description = 'Stick',
  type = 'material',
  info ='a stick',
  MAX_ITEMS = 1,
}
