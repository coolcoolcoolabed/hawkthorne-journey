return{
  name = 'leaf',
  description = 'Leaf',
  type = 'material',
  info = 'a normal leaf',
  MAX_ITEMS = 1,
}
