return{
  name = 'mushroom',
  description = 'Mushroom',
  type = 'material',
  info = 'a limp mushroom',
  MAX_ITEMS = 10,
}
