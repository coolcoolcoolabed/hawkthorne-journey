return{
  name = 'blade',
  description = 'Blade',
  type = 'material',
  info = 'a single blade, to small to be used as a weapon',
  MAX_ITEMS = 1,
  width = 5,
}