return{
  name = 'keyshardtop',
  type = 'material',
  info = 'this appears to be the top half of a key',
  MAX_ITEMS = 1,
}
