return{
  name = 'crystal',
  description = 'Crystal',
  type = 'material',
  info = 'a small, perfectly see-through ice crystal',
  MAX_ITEMS = 1,
}