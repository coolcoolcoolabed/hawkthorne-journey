return{
  name = 'bone',
  description = 'Bone',
  type = 'material',
  info = 'all that remains of some long dead creature',
  MAX_ITEMS = 1,
}