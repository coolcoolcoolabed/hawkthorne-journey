return{
  name = 'ember',
  description = 'Ember',
  type = 'material',
  info = 'a flamless ember which never goes out',
  MAX_ITEMS = 1,
}