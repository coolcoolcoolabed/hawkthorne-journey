return{
  name = 'keyshardbottom',
  type = 'material',
  info = 'this appears to be the the bottom half of a key',
  MAX_ITEMS = 1,
}
