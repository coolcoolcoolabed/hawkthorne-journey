return{
  name = 'flowers',
  description = 'Flowers',
  type = 'material',
  info = 'several flowers',
  MAX_ITEMS = 10,
}
