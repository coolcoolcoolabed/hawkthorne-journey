return{
  name = 'toast',
  description = 'Toast',
  type = 'material',
  info = 'a slice of toast',
  MAX_ITEMS = 10,
}
