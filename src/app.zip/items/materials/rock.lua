return{
  name = 'rock',
  description = 'Rock',
  type = 'material',
  info = 'a rock',
  MAX_ITEMS = 1,
}
