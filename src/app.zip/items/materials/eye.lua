return{
  name = 'eye',
  description = 'Eye',
  type = 'material',
  info = 'a single human eyeball',
  MAX_ITEMS = 10,
}
