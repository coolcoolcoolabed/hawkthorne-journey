return{
  name = 'peanut',
  description = 'Peanut',
  type = 'material',
  info = 'a peanut shell',
  MAX_ITEMS = 10,
}
