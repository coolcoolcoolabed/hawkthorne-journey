return{
  name = 'carkeys',
  description = 'Car Keys',
  type = 'material',
  info = 'a set of ownerless car keys',
  MAX_ITEMS = 10,
}
