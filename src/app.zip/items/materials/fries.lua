return{
  name = 'fries',
  description = 'Fries',
  type = 'material',
  info = 'yum!',
  MAX_ITEMS = 10,
}
