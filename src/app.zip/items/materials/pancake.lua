return{
  name = 'pancake',
  description = 'Pancake',
  type = 'material',
  info = 'a single pancake, hardened from age',
  MAX_ITEMS = 10,
}
