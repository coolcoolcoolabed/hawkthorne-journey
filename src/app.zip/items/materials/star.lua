return{
  name = 'star',
  description = 'Star',
  type = 'material',
  info = 'a star',
  MAX_ITEMS = 10,
}
