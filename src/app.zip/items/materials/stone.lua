return{
  name = 'stone',
  description = 'Stone',
  type = 'material',
  info = 'a slightly bigger rock',
  MAX_ITEMS = 1,
}
