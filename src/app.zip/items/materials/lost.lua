return{
  name = 'lost',
  description = 'Lost DVD',
  type = 'material',
  info = "it's a metaphor",
  MAX_ITEMS = 1,
}