return{
  name = 'banana',
  description = 'Banana',
  type = 'material',
  info = 'a banana',
  MAX_ITEMS = 10,
}
