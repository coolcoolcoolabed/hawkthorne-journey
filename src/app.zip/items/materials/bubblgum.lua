return{
  name = 'bubblgum',
  description = 'Bubble Gum',
  type = 'material',
  info = 'a single stick of gum, cotton candy flavor',
  MAX_ITEMS = 10,
}
