return{
  name = 'boulder',
  description = 'Boulder',
  type = 'material',
  info = 'a slightly larger stone',
  MAX_ITEMS = 1,
}