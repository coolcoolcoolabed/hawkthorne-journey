return{
  name = 'duck',
  description = 'Duck',
  type = 'material',
  info = 'an adult duck, who does not appreciate being carried',
  MAX_ITEMS = 10,
}
