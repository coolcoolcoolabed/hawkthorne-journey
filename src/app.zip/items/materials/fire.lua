return{
  name = 'fire',
  description = 'Fire',
  type = 'material',
  info = 'an eternal flame',
  MAX_ITEMS = 1,
}