return{
  name = 'frog',
  description = 'Frog',
  type = 'material',
  info = 'a single, dead frog',
  MAX_ITEMS = 10,
}
