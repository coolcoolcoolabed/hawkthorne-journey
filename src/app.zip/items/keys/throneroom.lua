return{
  name = "throneroom",
  description = "Throne Room",    
  type = "key",
  subtype = "key",
  info = "the key to the throne room of castle hawkthorne",
  MAX_ITEMS = 5,
  quantity = 1,
  directory = 'keys/'
}
