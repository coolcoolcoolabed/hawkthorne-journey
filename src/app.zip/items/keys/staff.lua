return{
  name = "staff",
  description = "Staff Key",
  type = "key",
  info = "The Key to the Staff Only Door",
  MAX_ITEMS = 1,
}
