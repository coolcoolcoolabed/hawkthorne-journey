return{
  name = "black_caverns",
  description = "Black Caverns",
  type = "key",
  info = "the key to open the black caverns",
  MAX_ITEMS = 1,
}
