return{
  name = "greendale",
  description = "Greendale",
  type = "key",
  info = "a key that is rumored to open a secret door to a place named 'Greendale'",
  MAX_ITEMS = 1,
}
