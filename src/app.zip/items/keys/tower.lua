return{
  name = "tower",
  description = "Tower",
  type = "key",
  info = "the key to the first tower of castle hawkthorne",
  subtype = "key",
  MAX_ITEMS = 5,
  quantity = 1,
  directory = 'keys/'
}
