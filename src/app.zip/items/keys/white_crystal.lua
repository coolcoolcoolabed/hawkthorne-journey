return{
  name = "white_crystal",
  description = "White Crystal",
  type = "key",
  info = "the key to castle hawkthorne",
  MAX_ITEMS = 1,
}
