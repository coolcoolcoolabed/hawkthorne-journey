return{
  name = "rusted_brass",
  description = "Rusted Brass",
  type = "key",
  info = "an old, rusted brass key",
  MAX_ITEMS = 1,
}
