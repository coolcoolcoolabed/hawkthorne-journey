return{
  name = "lost_dvd",
  description = "Lost DVD",
  type = "key",
  info = "the meaning of Christmas",
  MAX_ITEMS = 1,
}
