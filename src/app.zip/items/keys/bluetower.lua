return{
  name = "bluetower",
  description = "Blue Tower",
  type = "key",
  subtype = "key",
  info = "the key to castle hawkthorne's blue tower",
  MAX_ITEMS = 5,
  quantity = 1,
  directory = 'keys/'
}
