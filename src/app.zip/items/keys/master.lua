return{
  name = "master",
  description = "Master",
  type = "key",
  info = "The Key to Everything!",
  MAX_ITEMS = 1,
}
