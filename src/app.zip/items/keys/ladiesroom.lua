return{
  name = "ladiesroom",
  description = "Ladies Room",
  type = "key",
  info = "the key to the ladies room",
  MAX_ITEMS = 1,
}
