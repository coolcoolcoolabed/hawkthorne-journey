-- made by Nicko21
return{
  name = "pink_potion",
  description = "Max Health Potion",
  type = "consumable",
  info = 'a full heal potion',
  MAX_ITEMS = 2,
  width = 24,
  consumable = {heal = 'max'},
}
