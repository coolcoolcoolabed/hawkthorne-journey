-- made by Nicko21
return{
  name = "pickled_bull_testicles",
  description = "Pickled Bull Testicles",
  type = "consumable",
  info = 'Are you offering or collecting?',
  MAX_ITEMS = 2,
  width = 24,
  consumable = {heal = 5},
}
