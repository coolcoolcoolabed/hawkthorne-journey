return{
  name = "alcohol",
  description = "Alcohol",
  type = "consumable",
  MAX_ITEMS = 10,
  info = "please drink responsibly",
  width = 24,
  consumable = {alcohol = true},
}