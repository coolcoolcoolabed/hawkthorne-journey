-- made by Nicko21
return{
  name = "red_potion",
  description = "Health Potion",
  type = "consumable",
  info = 'heals for 25hp',
  MAX_ITEMS = 2,
  width = 24,
  consumable = {heal = 25},
}
