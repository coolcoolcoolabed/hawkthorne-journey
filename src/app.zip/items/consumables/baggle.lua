return{
  name = "baggle",
  description = "Baggle",
  type = "consumable",
  MAX_ITEMS = 10,
  info = "a tasty baggle with restorative powers",
  width = 24,
  consumable = {heal = 'max'}
}
