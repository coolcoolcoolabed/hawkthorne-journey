return{
  name = "watermelon",
  description = "Watermelon",
  type = "consumable",
  info="a refreshing snack",
  MAX_ITEMS = 50,
  width = 24,
  consumable = {heal = 0.5},
}
