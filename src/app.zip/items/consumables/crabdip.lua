return{
  name = "crabdip",
  description = "Crab Dip",
  type = "consumable",
  info="Dont Eat the Crab Dip yea-yea",
  MAX_ITEMS = 50,
  width = 24,
  consumable = {heal = 0.5},
}
