return{
  name = "tacomeat",
  description = "Taco Meat",
  type = "consumable",
  info = "Classified Phoenix",
  MAX_ITEMS = 10,
  width = 24,
  consumable = {zombie = true},
}