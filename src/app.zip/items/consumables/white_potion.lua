-- made by Nicko21
return{
  name = "white_potion",
  description = "Greater Health Potion",
  type = "consumable",
  info = 'heals for 50hp',
  MAX_ITEMS = 2,
  width = 24,
  consumable = {heal = 50},
}
