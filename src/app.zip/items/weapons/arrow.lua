return{
  name = "arrow",
  description = "Arrow",
  type = "weapon",
  subtype = "ammo",
  damage = 2,
  special_damage = 'stab= 1',
  info = 'a set of 5 arrows',
  MAX_ITEMS = 40,
  quantity = 5,
  directory = 'weapons/',
}
