-----------------------------------------------
-- cherrypopperItem.lua
-- The code for the cherrypopper, when it is in the player's inventory.
-- Created by NimbusBP1729
-----------------------------------------------

return{
  name = 'cherrypopper',
  description = 'Cherrypopper',
  type = 'weapon',
  subtype = 'melee',
  damage = '7',
  special_damage = 'ice= 1',
  info = 'a mighy weapon forged by the freespirits of Gay Island',
}
