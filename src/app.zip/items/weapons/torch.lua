-----------------------------------------------
-- torchItem.lua
-- The code for the torch, when it is in the player's inventory.
-- Created by NimbusBP1729
-----------------------------------------------

return{
  name = 'torch',
  description = 'Torch',
  type = 'weapon',
  subtype = 'melee',
  damage = '2',
  special_damage = 'fire= 3',
  info = 'a standard torch',
}
