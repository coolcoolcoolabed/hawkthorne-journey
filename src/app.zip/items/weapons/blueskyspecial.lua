-----------------------------------------------
-- blueskyspecialItem.lua
-- The code for the blueskyspecial, when it is in the player's inventory.
-- Created by NimbusBP1729
-----------------------------------------------

return{
  name = 'blueskyspecial',
  description = 'Blue Sky Special',
  type = 'weapon',
  subtype = 'melee',
  damage = '10',
  special_damage = 'blunt=2, stab=2, slash=2, ice=2, fire=2',
  info = 'a rare homemade weapon...',
}
