return{
  name = 'bow',
  description = 'Bow',
  type = 'weapon',
  subtype = 'ranged',
  ammo = 'arrow',
  damage = '0',
  special_damage = 'none',
  info = 'a bow',
}
