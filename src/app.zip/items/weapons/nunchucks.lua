-----------------------------------------------
-- swordItem.lua
-- The code for the sword, when it is in the player's inventory.
-- Created by NimbusBP1729
-----------------------------------------------

return{
  name = 'nunchucks',
  description = 'Nunchucks',
  type = 'weapon',
  subtype = 'melee',
  info = 'a deadly pair of nunchucks',
  damage = 2,
  special_damage = 'blunt= 1',
}
