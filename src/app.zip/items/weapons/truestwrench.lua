-----------------------------------------------
-- maletItem.lua
-- The code for the mace, when it is in the player's inventory.
-- Created by NimbusBP1729
-----------------------------------------------

return{
  name = 'truestwrench',
  description = 'Truest Wrench', 
  type = 'weapon',
  subtype = 'melee',
  damage = '10',
  special_damage = 'blunt= 2, dismantle= 20',
  info = 'a wrench fit for the truest of AC repairmen',
}
