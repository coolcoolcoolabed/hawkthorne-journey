return{
    name = "ghost_pepper",
    description = "Ghostly Summons",
    type = "scroll",
    subtype = "projectile",
    damage = "5-10",
    special_damage = 'ice= 2,fire= 2',
  	info = 'Summons the ghost of peppers past',
    MAX_ITEMS = 5,
    quantity = 1,
    directory = 'scrolls/'
}
