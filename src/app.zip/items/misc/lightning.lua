return{
  name = "lightning",
  description = "Lightning",
  type = "scroll",
  subtype = "projectile",
  damage = "4-20",
  special_damage = 'lightning= 4',
  info = 'an ancient spell used to strike down enemies',
  MAX_ITEMS = 5,
  quantity = 1,
  directory = 'scrolls/'
}
