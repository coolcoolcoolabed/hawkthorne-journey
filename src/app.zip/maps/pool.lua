return {
  width = 39,
  height = 14,
  tilewidth = 24,
  tileheight = 24,
  orientation = "orthogonal",
  properties = { 
    ["autosave"] = "false",
    ["blue"] = "159",
    ["green"] = "123",
    ["red"] = "104",
    ["soundtrack"] = "greendale-alt",
    ["title"] = "Borchert Hallway",
  },
  tilesets = { 
    {
      name = "pool",
      tilewidth = 24,
      tileheight = 24,
      spacing = 0,
      margin = 0,
      image = {
        source = "../images/tilesets/pool.png",
        width = "240",
        height = "240",
      },
      properties = { 
      },
    },
    {
      name = "greendale-hallways",
      tilewidth = 24,
      tileheight = 24,
      spacing = 0,
      margin = 0,
      image = {
        source = "../images/tilesets/greendale-hallways.png",
        width = "576",
        height = "600",
      },
      properties = { 
      },
    },
    {
      name = "collisions",
      tilewidth = 24,
      tileheight = 24,
      spacing = 0,
      margin = 0,
      image = {
        source = "../images/tilesets/collisions.png",
        width = "632",
        height = "512",
      },
      properties = { 
      },
    },
  },
  tilelayers = { 
    {
      name = "bg",
      properties = { 
      },
      tiles = { {id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 48,},{id = 48,},{id = 47,},{id = 47, flipHorizontal = true,},{id = 48,},{id = 48,},{id = 47,},{id = 47, flipHorizontal = true,},{id = 48,},{id = 39,},{id = 2,},{id = 3,},{id = 4,},{id = 5,},{id = 6,},{id = 39,},{id = 48,},{id = 48,},{id = 47,},{id = 47, flipHorizontal = true,},{id = 48,},{id = 48,},{id = 47,},{id = 47, flipHorizontal = true,},{id = 48,},{id = 48,},{id = 47,},{id = 47, flipHorizontal = true,},{id = 48,},{id = 48,},{id = 47,},{id = 47, flipHorizontal = true,},{id = 48,},{id = 48,},{id = 47,},{id = 47, flipHorizontal = true,},{id = 48,},{id = 47,},{id = 47, flipHorizontal = true,},{id = 49,},{id = 49,},{id = 46,},{id = 46, flipHorizontal = true,},{id = 49,},{id = 49,},{id = 46,},{id = 46, flipHorizontal = true,},{id = 49,},{id = 39,},{id = 39,},{id = 39,},{id = 39,},{id = 39,},{id = 39,},{id = 39,},{id = 44,},{id = 44,},{id = 44,},{id = 44,},{id = 44,},{id = 44,},{id = 44,},{id = 44,},{id = 44,},{id = 44,},{id = 44,},{id = 44,},{id = 44,},{id = 44,},{id = 44,},{id = 44,},{id = 44,},{id = 44,},{id = 44,},{id = 44,},{id = 44,},{id = 44,},{id = 44,},{id = 49,},{id = 49,},{id = 46,},{id = 46, flipHorizontal = true,},{id = 49,},{id = 49,},{id = 46,},{id = 46, flipHorizontal = true,},{id = 49,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 43,},{id = 43,},{id = 43,},{id = 43,},{id = 43,},{id = 43,},{id = 43,},{id = 43,},{id = 43,},{id = 43,},{id = 43,},{id = 43,},{id = 43,},{id = 43,},{id = 43,},{id = 43,},{id = 43,},{id = 43,},{id = 43,},{id = 43,},{id = 43,},{id = 43,},{id = 43,},{id = 49,},{id = 49,},{id = 46,},{id = 46, flipHorizontal = true,},{id = 49,},{id = 49,},{id = 46,},{id = 46, flipHorizontal = true,},{id = 49,},{id = 49,},{id = 49,},{id = 49,},{id = 49,},{id = 49,},{id = 49,},{id = 49,},{id = 49,},{id = 43,},{id = 43,},{id = 43,},{id = 43,},{id = 43,},{id = 43,},{id = 43,},{id = 43,},{id = 43,},{id = 43,},{id = 43,},{id = 43,},{id = 43,},{id = 43,},{id = 43,},{id = 43,},{id = 43,},{id = 43,},{id = 43,},{id = 43,},{id = 43,},{id = 43,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,}, },
    },
    {
      name = "Tile Layer 1",
      properties = { 
      },
      tiles = { {id = 32,},{id = 32,},{id = 32,},{id = 32,},{id = 32,},{id = 32,},{id = 32,},{id = 32,},{id = 32,},{id = 32,},{id = 32,},{id = 32,},{id = 32,},{id = 32,},{id = 32,},{id = 32,},{id = 32,},{id = 32,},{id = 32,},{id = 32,},{id = 32,},{id = 32,},{id = 32,},{id = 31,},{id = 31,},{id = 31,},{id = 30,},{id = 30,},{id = 30,},{id = 21,},{id = 21,},{id = 21,},{id = 21,},{id = 21,},{id = 21,},{id = 21,},{id = 20,},{id = 20,},false,{id = 32,},{id = 32,},{id = 32,},{id = 32,},{id = 32,},{id = 32,},{id = 32,},{id = 32,},{id = 32,},{id = 32,},{id = 32,},{id = 32,},{id = 32,},{id = 32,},{id = 32,},{id = 32,},{id = 32,},{id = 32,},{id = 32,},{id = 32,},{id = 32,},{id = 32,},{id = 31,},{id = 31,},{id = 31,},{id = 31,},{id = 30,},{id = 30,},{id = 30,},{id = 21,},{id = 21,},{id = 21,},{id = 21,},{id = 21,},{id = 21,},{id = 20,},{id = 20,},{id = 20,},false,{id = 32,},{id = 32,},{id = 32,},{id = 32,},{id = 32,},{id = 32,},{id = 32,},{id = 32,},{id = 32,},{id = 32,},{id = 32,},{id = 32,},{id = 32,},{id = 32,},{id = 32,},{id = 32,},{id = 32,},{id = 32,},{id = 32,},{id = 32,},{id = 32,},{id = 31,},{id = 31,},{id = 31,},{id = 31,},{id = 30,},{id = 30,},{id = 30,},{id = 21,},{id = 21,},{id = 21,},{id = 21,},{id = 21,},{id = 21,},{id = 20,},{id = 20,},false,{id = 20,},false,{id = 32,},{id = 32,},{id = 32,},{id = 32,},{id = 32,},{id = 32,},{id = 32,},{id = 32,},{id = 32,},{id = 32,},{id = 32,},{id = 32,},{id = 32,},{id = 32,},{id = 32,},{id = 32,},{id = 32,},{id = 32,},{id = 32,},{id = 32,},{id = 31,},{id = 31,},{id = 31,},{id = 31,},{id = 31,},{id = 30,},{id = 30,},{id = 30,},{id = 21,},{id = 21,},{id = 21,},{id = 21,},{id = 21,},{id = 21,},{id = 20,},{id = 20,},{id = 20,},{id = 20,},false,{id = 32,},{id = 32,},{id = 32,},{id = 32,},{id = 32,},{id = 32,},{id = 32,},{id = 32,},{id = 32,},{id = 32,},{id = 32,},{id = 32,},{id = 32,},{id = 32,},{id = 32,},{id = 32,},{id = 32,},{id = 32,},{id = 31,},{id = 31,},{id = 31,},{id = 31,},{id = 31,},{id = 31,},{id = 30,},{id = 30,},{id = 30,},{id = 21,},{id = 21,},{id = 21,},{id = 21,},{id = 21,},{id = 21,},{id = 20,},{id = 20,},{id = 20,},{id = 20,},false,false,{id = 32,},{id = 32,},{id = 32,},{id = 32,},{id = 32,},{id = 32,},{id = 32,},{id = 32,},{id = 32,},{id = 32,},{id = 32,},{id = 32,},{id = 32,},{id = 32,},{id = 32,},{id = 32,},{id = 32,},{id = 32,},{id = 31,},{id = 31,},{id = 31,},{id = 31,},{id = 31,},{id = 30,},{id = 30,},{id = 30,},{id = 30,},{id = 21,},{id = 21,},{id = 21,},{id = 21,},{id = 21,},{id = 20,},{id = 20,},{id = 20,},{id = 20,},{id = 20,},false,false,{id = 32,},{id = 32,},{id = 32,},{id = 32,},{id = 32,},{id = 32,},{id = 32,},{id = 32,},{id = 68,},{id = 68,},{id = 68,},{id = 68,},{id = 68,},{id = 68,},{id = 68,},{id = 68,},{id = 68,},{id = 68,},{id = 31,},{id = 31,},{id = 31,},{id = 31,},{id = 31,},{id = 30,},{id = 30,},{id = 68,},{id = 21,},{id = 68,},{id = 21,},{id = 21,},{id = 20,},{id = 20,},{id = 20,},{id = 20,},{id = 68,},{id = 20,},{id = 20,},{id = 68,},{id = 68,},false,false,false,false,false,false,false,false,false,{id = 38, flipHorizontal = true, flipVertical = true,},false,false,false,false,false,{id = 38,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 33, flipHorizontal = true, flipDiagonal = true,},{id = 23, flipHorizontal = true, flipDiagonal = true,},{id = 33, flipHorizontal = true, flipDiagonal = true,},{id = 23, flipHorizontal = true, flipDiagonal = true,},{id = 33, flipHorizontal = true, flipDiagonal = true,},{id = 23, flipHorizontal = true, flipDiagonal = true,},false,false,{id = 38, flipHorizontal = true, flipVertical = true,},false,false,false,{id = 57,},false,{id = 38,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 23,},{id = 26, flipHorizontal = true,},{id = 26,},{id = 26, flipHorizontal = true,},{id = 26,},{id = 24,},false,false,false,{id = 68,},{id = 68,},{id = 68,},{id = 65,},{id = 64, flipHorizontal = true,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 33,},{id = 36, flipHorizontal = true,},{id = 36,},{id = 36, flipHorizontal = true,},{id = 36,},{id = 34,},false,{id = 45,},{id = 45,},{id = 45,},{id = 45,},{id = 45,},{id = 45,},{id = 45,},{id = 45,},{id = 45,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 52,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 52,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 51,},{id = 52,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false, },
    },
    {
      name = "Tile Layer 2",
      properties = { 
      },
      tiles = { false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 68,},{id = 68,},{id = 68,},{id = 68,},{id = 68,},{id = 68,},{id = 68,},{id = 68,},{id = 68,},{id = 68,},{id = 68,},{id = 68,},{id = 68,},{id = 68,},{id = 68,},{id = 68,},{id = 68,},{id = 68,},{id = 68,},{id = 68,},{id = 68,},{id = 68,},{id = 68,},{id = 68,},{id = 68,},{id = 68,},{id = 68,},{id = 68,},{id = 68,},{id = 68,},{id = 68,},{id = 68,},{id = 68,},{id = 68,},{id = 68,},{id = 68,},{id = 68,},{id = 68,},{id = 68,},false,false,false,false,false,false,false,false,false,{id = 38, flipVertical = true, flipDiagonal = true,},{id = 38, flipVertical = true, flipDiagonal = true,},{id = 38, flipVertical = true, flipDiagonal = true,},{id = 38, flipVertical = true, flipDiagonal = true,},{id = 38, flipVertical = true, flipDiagonal = true,},{id = 38, flipVertical = true, flipDiagonal = true,},{id = 38, flipVertical = true, flipDiagonal = true,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 72,},{id = 73,},{id = 74,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 82,},{id = 83,},{id = 84,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false, },
    },
    {
      name = "Tile Layer 3",
      properties = { 
      },
      tiles = { false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 54,},{id = 55,},{id = 56,},{id = 57,},{id = 58,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 64,},{id = 65,},{id = 65,},{id = 67,},false,false,false,{id = 76,},{id = 77,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 86,},{id = 87,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 42,},{id = 42,},{id = 42,},{id = 42,},{id = 42,},{id = 42,},{id = 42,},{id = 42,},{id = 42,},{id = 42,},{id = 42,},{id = 42,},{id = 42,},{id = 42,},{id = 42,},{id = 42,},{id = 42,},{id = 42,},{id = 42,},{id = 42,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 42,},{id = 42,},{id = 42,},{id = 42,},{id = 42,},{id = 42,},{id = 42,},{id = 42,},{id = 42,},{id = 42,},{id = 42,},{id = 42,},{id = 42,},{id = 42,},{id = 42,},{id = 42,},{id = 42,},{id = 42,},{id = 42,},{id = 42,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 42,},{id = 42,},{id = 42,},{id = 42,},{id = 42,},{id = 42,},{id = 42,},{id = 42,},{id = 42,},{id = 42,},{id = 42,},{id = 42,},{id = 42,},{id = 42,},{id = 42,},{id = 42,},{id = 42,},{id = 42,},{id = 42,},{id = 42,}, },
    },
    {
      name = "collision",
      properties = { 
      },
      tiles = { false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 47,},{id = 47,},{id = 47,},{id = 47,},{id = 47,},{id = 47,},{id = 47,},{id = 47,},{id = 47,},{id = 47,},{id = 47,},{id = 47,},{id = 47,},{id = 47,},{id = 47,},{id = 47,},{id = 47,},{id = 47,},{id = 47,},{id = 47,},{id = 47,},{id = 47,},{id = 47,},{id = 47,},{id = 47,},{id = 47,},{id = 47,},{id = 47,},{id = 47,},{id = 47,},{id = 47,},{id = 47,},{id = 47,},{id = 47,},{id = 47,},{id = 47,},{id = 47,},{id = 47,},{id = 47,},{id = 26,},{id = 26,},{id = 26,},{id = 26,},{id = 26,},{id = 26,},{id = 26,},{id = 26,},{id = 26,},{id = 26,},{id = 26,},{id = 26,},{id = 26,},{id = 26,},{id = 26,},{id = 26,},{id = 26,},{id = 26,},{id = 26,},{id = 26,},{id = 26,},{id = 26,},{id = 26,},{id = 26,},{id = 26,},{id = 26,},{id = 26,},{id = 26,},{id = 26,},{id = 26,},{id = 26,},{id = 26,},{id = 26,},{id = 26,},{id = 26,},{id = 26,},{id = 26,},{id = 26,},{id = 26,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 51,},{id = 26,},{id = 26,},{id = 26,},{id = 50,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 26,},{id = 26,},{id = 26,},{id = 26,},{id = 26,},{id = 26,},{id = 26,},{id = 26,},{id = 26,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 0,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 0,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false, },
    },
  },
  objectgroups = { 
    ["nodes"] = {
      name = "nodes",
      properties = { 
      },
      objects = { 
        {
          name = "main",
          x = 48,
          y = 216,
          width = 96,
          height = 48,
          type = "door",
          
          
          properties = { 
            ["level"] = "borchert-hallway",
            ["to"] = "pool",
          },
        },
        {
          name = "",
          x = 415,
          y = 227,
          width = 31,
          height = 36,
          type = "info",
          
          
          properties = { 
            ["info"] = "Busted! Hahaha!",
          },
        },
        {
          name = "",
          x = 456,
          y = 264,
          width = 480,
          height = 72,
          type = "liquid",
          
          
          properties = { 
            ["drag"] = "true",
            ["opacity"] = "0.7",
            ["speed"] = "0.2",
            ["sprite"] = "images/liquid/water2.png",
          },
        },
        {
          name = "",
          x = 266,
          y = 200,
          width = 19,
          height = 38,
          type = "info",
          
          
          properties = { 
            ["info"] = "state-of-the-art judge's table, which has its own built-in sound system,| so take that Yale.",
          },
        },
        {
          name = "",
          x = 290,
          y = 200,
          width = 19,
          height = 38,
          type = "info",
          
          
          properties = { 
            ["info"] = " Yeah, well, you got prince Charles over here, who's your drinking buddy. ",
          },
        },
        {
          name = "",
          x = 243,
          y = 199,
          width = 19,
          height = 38,
          type = "info",
          
          
          properties = { 
            ["info"] = " That's the difference. That's the qualifying factor. ",
          },
        },
      },
    },
  }
}