return {
  width = 22,
  height = 14,
  tilewidth = 24,
  tileheight = 24,
  orientation = "orthogonal",
  properties = { 
    ["autosave"] = "false",
    ["soundtrack"] = "greendale-alt",
  },
  tilesets = { 
    {
      name = "greendale-classrooms",
      tilewidth = 24,
      tileheight = 24,
      spacing = 0,
      margin = 0,
      image = {
        source = "../images/tilesets/greendale-classrooms.png",
        width = "288",
        height = "479",
      },
      properties = { 
      },
    },
    {
      name = "collisions",
      tilewidth = 24,
      tileheight = 24,
      spacing = 0,
      margin = 0,
      image = {
        source = "../images/tilesets/collisions.png",
        width = "632",
        height = "512",
      },
      properties = { 
      },
    },
  },
  tilelayers = { 
    {
      name = "bg",
      properties = { 
      },
      tiles = { {id = 5,},{id = 5,},{id = 5,},{id = 5,},{id = 5,},{id = 5,},{id = 5,},{id = 5,},{id = 5,},{id = 5,},{id = 5,},{id = 5,},{id = 5,},{id = 5,},{id = 5,},{id = 5,},{id = 5,},{id = 5,},{id = 5,},{id = 5,},{id = 5,},{id = 5,},{id = 6, flipHorizontal = true,},{id = 6, flipHorizontal = true,},{id = 6, flipHorizontal = true,},{id = 6, flipHorizontal = true,},{id = 6, flipHorizontal = true,},{id = 6, flipHorizontal = true,},{id = 6, flipHorizontal = true,},{id = 6, flipHorizontal = true,},{id = 6, flipHorizontal = true,},{id = 6, flipHorizontal = true,},{id = 6, flipHorizontal = true,},{id = 6, flipHorizontal = true,},{id = 6, flipHorizontal = true,},{id = 6, flipHorizontal = true,},{id = 6, flipHorizontal = true,},{id = 6, flipHorizontal = true,},{id = 6, flipHorizontal = true,},{id = 6, flipHorizontal = true,},{id = 6, flipHorizontal = true,},{id = 6, flipHorizontal = true,},{id = 6, flipHorizontal = true,},{id = 6, flipHorizontal = true,},{id = 6, flipHorizontal = true,},{id = 6, flipHorizontal = true,},{id = 6, flipHorizontal = true,},{id = 6, flipHorizontal = true,},{id = 6, flipHorizontal = true,},{id = 6, flipHorizontal = true,},{id = 6, flipHorizontal = true,},{id = 6, flipHorizontal = true,},{id = 6, flipHorizontal = true,},{id = 6, flipHorizontal = true,},{id = 6, flipHorizontal = true,},{id = 6, flipHorizontal = true,},{id = 6, flipHorizontal = true,},{id = 6, flipHorizontal = true,},{id = 6, flipHorizontal = true,},{id = 6, flipHorizontal = true,},{id = 6, flipHorizontal = true,},{id = 6, flipHorizontal = true,},{id = 6, flipHorizontal = true,},{id = 6, flipHorizontal = true,},{id = 6, flipHorizontal = true,},{id = 6, flipHorizontal = true,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 12,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 1,},{id = 24,},{id = 1,},{id = 1,},{id = 1,},{id = 1,},{id = 1,},{id = 1,},{id = 1,},{id = 1,},{id = 1,},{id = 1,},{id = 1,},{id = 1,},{id = 1,},{id = 1,},{id = 1,},{id = 1,},{id = 1,},{id = 1,},{id = 1,},{id = 1,},{id = 3,},{id = 3,},{id = 3,},{id = 3,},{id = 3,},{id = 3,},{id = 3,},{id = 3,},{id = 3,},{id = 3,},{id = 3,},{id = 3,},{id = 3,},{id = 3,},{id = 3,},{id = 3,},{id = 3,},{id = 3,},{id = 3,},{id = 3,},{id = 3,},{id = 3,},{id = 2,},{id = 2,},{id = 2,},{id = 2,},{id = 2,},{id = 2,},{id = 2,},{id = 2,},{id = 2,},{id = 2,},{id = 2,},{id = 2,},{id = 2,},{id = 2,},{id = 2,},{id = 2,},{id = 2,},{id = 2,},{id = 2,},{id = 2,},{id = 2,},{id = 2,},{id = 4,},{id = 4,},{id = 4,},{id = 4,},{id = 4,},{id = 4,},{id = 4,},{id = 4,},{id = 4,},{id = 4,},{id = 4,},{id = 4,},{id = 4,},{id = 4,},{id = 4,},{id = 4,},{id = 4,},{id = 4,},{id = 4,},{id = 4,},{id = 4,},{id = 4,}, },
    },
    {
      name = "walldecor",
      properties = { 
      },
      tiles = { false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 9,},false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 30,},false,{id = 14,},{id = 15,},{id = 15,},{id = 15,},{id = 15,},{id = 15,},{id = 15,},{id = 14, flipHorizontal = true,},false,false,false,false,false,false,false,false,false,false,false,{id = 65,},{id = 66,},false,{id = 26,},{id = 27,},{id = 27,},{id = 27,},{id = 27,},{id = 27,},{id = 27,},{id = 26, flipHorizontal = true,},false,false,{id = 62,},{id = 63,},{id = 64,},false,false,{id = 7,},false,false,false,{id = 77,},{id = 78,},false,{id = 26,},{id = 27,},{id = 27,},{id = 27,},{id = 27,},{id = 27,},{id = 27,},{id = 26, flipHorizontal = true,},false,false,{id = 74,},{id = 75,},{id = 76,},false,false,false,false,false,false,false,false,false,{id = 14, flipVertical = true,},{id = 15, flipHorizontal = true, flipVertical = true,},{id = 15, flipHorizontal = true, flipVertical = true,},{id = 15, flipHorizontal = true, flipVertical = true,},{id = 15, flipHorizontal = true, flipVertical = true,},{id = 15, flipHorizontal = true, flipVertical = true,},{id = 15, flipHorizontal = true, flipVertical = true,},{id = 14, flipHorizontal = true, flipVertical = true,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false, },
    },
    {
      name = "podium",
      properties = { 
      },
      tiles = { false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 69,},{id = 70,},{id = 71,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 81,},{id = 82,},{id = 83,},false,false,false,false,false,false,false,false,false,false,{id = 61,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 73,},false,false,false,false,false,false,{id = 60,},{id = 60, flipHorizontal = true,},false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 73,},false,false,false,false,false,false,{id = 72,},{id = 72, flipHorizontal = true,},false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 85,},false,false,false,false,false,false,{id = 84,},{id = 84, flipHorizontal = true,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false, },
    },
    {
      name = "seats",
      properties = { 
        ["foreground"] = "true",
      },
      tiles = { false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 16,},{id = 17,},false,{id = 16,},{id = 17,},false,{id = 16,},{id = 17,},false,false,{id = 17, flipHorizontal = true,},{id = 16, flipHorizontal = true,},false,{id = 17, flipHorizontal = true,},{id = 16, flipHorizontal = true,},false,{id = 17, flipHorizontal = true,},{id = 16, flipHorizontal = true,},false,false,false,false,{id = 28,},{id = 29,},false,{id = 28,},{id = 29,},false,{id = 28,},{id = 29,},false,false,{id = 29, flipHorizontal = true,},{id = 28, flipHorizontal = true,},false,{id = 29, flipHorizontal = true,},{id = 28, flipHorizontal = true,},false,{id = 29, flipHorizontal = true,},{id = 28, flipHorizontal = true,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false, },
    },
    {
      name = "ladder",
      properties = { 
      },
      tiles = { false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 97,},{id = 98,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 109,},{id = 110,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 120,},{id = 121,},{id = 122,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 132,},{id = 133,},{id = 134,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false, },
    },
    {
      name = "collision",
      properties = { 
      },
      tiles = { {id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 51,},{id = 50,},false,false,false,false,false,false,false,false,false,{id = 21,},{id = 21,},{id = 21,},{id = 21,},{id = 21,},{id = 21,},{id = 21,},{id = 21,},{id = 21,},{id = 21,},{id = 21,},{id = 21,},{id = 21,},{id = 21,},{id = 21,},{id = 21,},{id = 21,},{id = 21,},{id = 21,},{id = 21,},{id = 21,},{id = 21,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false, },
    },
  },
  objectgroups = { 
    ["nodes"] = {
      name = "nodes",
      properties = { 
      },
      objects = { 
        {
          name = "main",
          x = 24,
          y = 216,
          width = 24,
          height = 60,
          type = "door",
          
          
          properties = { 
            ["level"] = "class-hallway",
            ["to"] = "ladders",
          },
        },
      },
    },
  }
}