return {
  width = 25,
  height = 24,
  tilewidth = 24,
  tileheight = 24,
  orientation = "orthogonal",
  properties = { 
    ["blue"] = "250",
    ["green"] = "222",
    ["offset"] = "36",
    ["overworldName"] = "forest_3",
    ["red"] = "115",
    ["soundtrack"] = "abeds-town",
  },
  tilesets = { 
    {
      name = "forest",
      tilewidth = 24,
      tileheight = 24,
      spacing = 0,
      margin = 0,
      image = {
        source = "../images/tilesets/forest.png",
        width = "216",
        height = "504",
      },
      properties = { 
      },
    },
    {
      name = "collisions",
      tilewidth = 24,
      tileheight = 24,
      spacing = 0,
      margin = 0,
      image = {
        source = "../images/tilesets/collisions.png",
        width = "632",
        height = "512",
      },
      properties = { 
      },
    },
  },
  tilelayers = { 
    {
      name = "background",
      properties = { 
      },
      tiles = { false,false,false,false,{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},false,false,false,false,false,false,false,false,{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},false,false,false,false,false,false,false,false,{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},false,false,false,false,false,false,false,false,{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},false,false,false,false,false,false,false,false,{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},false,false,false,false,false,false,false,false,{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},false,false,false,false,{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 40,},{id = 107,},{id = 107,},{id = 107,},{id = 107,},{id = 107,},{id = 107,},{id = 107,},{id = 107,},{id = 107,},{id = 107,},{id = 107,},{id = 107,},{id = 107,},{id = 107,},{id = 107,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 28,},{id = 28,},{id = 28,},{id = 28,},{id = 28,},{id = 28,},{id = 28,},{id = 28,},{id = 28,},{id = 28,},{id = 28,},{id = 37,},{id = 37,},{id = 37,},{id = 28,},{id = 28,},{id = 28,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,}, },
    },
    {
      name = "foreground",
      properties = { 
      },
      tiles = { {id = 49,},{id = 50,},{id = 49,},{id = 50,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 50,},{id = 49,},{id = 50,},{id = 49,},false,false,false,false,{id = 37,},{id = 56,},{id = 56,},{id = 56,},{id = 56,},{id = 56,},{id = 56,},{id = 56,},{id = 56,},{id = 56,},{id = 56,},{id = 56,},{id = 56,},{id = 56,},{id = 56,},{id = 56,},{id = 56,},false,false,false,false,false,false,false,false,{id = 37,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 37,},false,false,false,false,false,false,false,false,false,false,false,false,{id = 92,},{id = 96,},{id = 97,},false,false,false,false,false,false,false,false,false,{id = 37,},false,false,false,false,false,false,false,false,false,{id = 40,},false,false,{id = 101,},{id = 77,},{id = 106,},false,false,false,false,false,false,false,false,false,{id = 37,},false,false,false,false,false,false,false,false,false,false,false,false,{id = 101,},{id = 77,},{id = 106,},false,false,false,false,false,false,false,false,false,{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},false,false,false,false,false,false,false,false,{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false, },
    },
    {
      name = "Tile Layer 5",
      properties = { 
      },
      tiles = { false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 56,},{id = 56,},{id = 56,},{id = 56,},{id = 56,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 56,},{id = 56,},{id = 56,},{id = 56,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 101,},false,false,false,false,false,false,false,false,{id = 106,},false,false,{id = 85,},false,false,false,false,false,false,false,false,false,false,false,false,{id = 101,},false,false,false,false,false,false,false,false,{id = 106,},false,false,{id = 70,},false,false,false,false,false,false,false,false,false,false,false,false,{id = 101,},false,false,false,false,false,false,false,false,{id = 106,},false,false,{id = 70,},false,false,false,false,false,false,false,false,false,false,false,{id = 33,},{id = 33,},{id = 33,},{id = 33,},{id = 33,},{id = 33,},{id = 33,},{id = 33,},{id = 33,},{id = 33,},{id = 33,},{id = 33,},{id = 33,},{id = 33,},{id = 33,},false,false,false,false,false,false,false,false,false,false,{id = 33,},{id = 33,},{id = 33,},{id = 33,},{id = 33,},{id = 33,},{id = 33,},{id = 33,},{id = 33,},{id = 33,},{id = 33,},{id = 33,},{id = 33,},{id = 33,},{id = 33,},false,false,false,false,false,false,false,false,false,false,{id = 33,},{id = 33,},{id = 33,},{id = 33,},{id = 33,},{id = 33,},{id = 33,},{id = 33,},{id = 33,},{id = 33,},{id = 33,},{id = 33,},{id = 33,},{id = 33,},{id = 33,},false,false,false,false,false,false,false,false,false,false,{id = 33,},{id = 33,},{id = 33,},{id = 33,},{id = 33,},{id = 33,},{id = 33,},{id = 33,},{id = 33,},{id = 33,},{id = 33,},{id = 33,},{id = 33,},{id = 33,},{id = 33,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false, },
    },
    {
      name = "collision",
      properties = { 
      },
      tiles = { false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 21,},{id = 21,},{id = 21,},{id = 21,},{id = 21,},{id = 21,},{id = 21,},{id = 21,},{id = 21,},{id = 21,},{id = 21,},{id = 21,},{id = 21,},{id = 21,},{id = 21,},{id = 21,},false,false,false,false,false,false,false,false,{id = 0,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 0,},false,false,false,false,false,false,false,false,{id = 0,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 0,},false,false,false,false,false,false,false,false,{id = 0,},false,false,{id = 26,},{id = 26,},{id = 26,},{id = 26,},{id = 26,},{id = 26,},{id = 26,},{id = 26,},false,false,false,false,false,{id = 0,},false,false,false,false,false,false,false,false,{id = 0,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 0,},false,false,false,false,false,false,false,false,{id = 0,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 0,},false,false,false,false,false,false,false,false,{id = 0,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 0,},false,false,false,false,false,false,false,false,{id = 0,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 0,},false,false,false,false,false,false,false,false,{id = 0,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 0,},false,false,false,false,false,false,false,false,{id = 0,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 0,},false,false,false,false,false,false,false,false,{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false, },
    },
  },
  objectgroups = { 
    ["floorspace"] = {
      name = "floorspace",
      properties = { 
      },
      objects = { 
        {
          name = "",
          x = 120,
          y = 264,
          width = 360,
          height = 96,
          type = "",
          
          
          properties = { 
            ["primary"] = "true",
          },
        },
        {
          name = "",
          x = 384,
          y = 329,
          width = 24,
          height = 7,
          type = "",
          
          
          properties = { 
          },
        },
      },
    },
    ["nodes"] = {
      name = "nodes",
      properties = { 
      },
      objects = { 
        {
          name = "main",
          x = 432,
          y = 216,
          width = 24,
          height = 48,
          type = "door",
          
          
          properties = { 
            ["level"] = "eatery",
            ["sound"] = "false",
            ["to"] = "kitchen",
          },
        },
        {
          name = "",
          x = 168,
          y = 192,
          width = 24,
          height = 48,
          type = "sprite",
          
          
          properties = { 
            ["animation"] = "1-4,1",
            ["height"] = "48",
            ["sheet"] = "images/sprites/hermittown/deadfish.png",
            ["width"] = "24",
          },
        },
        {
          name = "chef",
          x = 168,
          y = 288,
          width = 48,
          height = 48,
          type = "npc",
          
          
          properties = { 
          },
        },
        {
          name = "",
          x = 192,
          y = 192,
          width = 24,
          height = 48,
          type = "sprite",
          
          
          properties = { 
            ["animation"] = "1-4,1",
            ["height"] = "48",
            ["sheet"] = "images/sprites/hermittown/deadfish.png",
            ["width"] = "24",
          },
        },
        {
          name = "",
          x = 216,
          y = 192,
          width = 24,
          height = 48,
          type = "sprite",
          
          
          properties = { 
            ["animation"] = "1-4,1",
            ["height"] = "48",
            ["sheet"] = "images/sprites/hermittown/deadfish.png",
            ["width"] = "24",
          },
        },
        {
          name = "",
          x = 240,
          y = 192,
          width = 24,
          height = 48,
          type = "sprite",
          
          
          properties = { 
            ["animation"] = "1-4,1",
            ["height"] = "48",
            ["sheet"] = "images/sprites/hermittown/deadfish.png",
            ["width"] = "24",
          },
        },
        {
          name = "",
          x = 264,
          y = 192,
          width = 24,
          height = 48,
          type = "sprite",
          
          
          properties = { 
            ["animation"] = "1-4,1",
            ["height"] = "48",
            ["sheet"] = "images/sprites/hermittown/deadfish.png",
            ["width"] = "24",
          },
        },
        {
          name = "",
          x = 288,
          y = 192,
          width = 24,
          height = 48,
          type = "sprite",
          
          
          properties = { 
            ["animation"] = "1-4,1",
            ["height"] = "48",
            ["sheet"] = "images/sprites/hermittown/deadfish.png",
            ["width"] = "24",
          },
        },
        {
          name = "",
          x = 312,
          y = 192,
          width = 24,
          height = 48,
          type = "sprite",
          
          
          properties = { 
            ["animation"] = "1-4,1",
            ["height"] = "48",
            ["sheet"] = "images/sprites/hermittown/deadfish.png",
            ["width"] = "24",
          },
        },
        {
          name = "",
          x = 336,
          y = 192,
          width = 24,
          height = 48,
          type = "sprite",
          
          
          properties = { 
            ["animation"] = "1-4,1",
            ["height"] = "48",
            ["sheet"] = "images/sprites/hermittown/deadfish.png",
            ["width"] = "24",
          },
        },
        {
          name = "",
          x = 384,
          y = 312,
          width = 24,
          height = 24,
          type = "cauldron",
          
          
          properties = { 
          },
        },
        {
          name = "",
          x = 312,
          y = 312,
          width = 48,
          height = 24,
          type = "sprite",
          
          
          properties = { 
            ["height"] = "48",
            ["sheet"] = "images/sprites/hermittown/spill.png",
            ["width"] = "24",
          },
        },
        {
          name = "",
          x = 384,
          y = 336,
          width = 48,
          height = 24,
          type = "sprite",
          
          
          properties = { 
            ["height"] = "48",
            ["sheet"] = "images/sprites/hermittown/spill.png",
            ["width"] = "24",
          },
        },
        {
          name = "",
          x = 336,
          y = 288,
          width = 48,
          height = 24,
          type = "sprite",
          
          
          properties = { 
            ["flip"] = "true",
            ["height"] = "48",
            ["sheet"] = "images/sprites/hermittown/spill.png",
            ["width"] = "24",
          },
        },
        {
          name = "",
          x = 216,
          y = 336,
          width = 24,
          height = 24,
          type = "sprite",
          
          
          properties = { 
            ["height"] = "24",
            ["sheet"] = "images/sprites/hermittown/deadfishground.png",
            ["width"] = "24",
          },
        },
        {
          name = "",
          x = 120,
          y = 264,
          width = 24,
          height = 24,
          type = "sprite",
          
          
          properties = { 
            ["flip"] = "true",
            ["height"] = "24",
            ["sheet"] = "images/sprites/hermittown/deadfishground.png",
            ["width"] = "24",
          },
        },
        {
          name = "",
          x = 336,
          y = 264,
          width = 24,
          height = 24,
          type = "sprite",
          
          
          properties = { 
            ["height"] = "24",
            ["sheet"] = "images/sprites/hermittown/deadfishground.png",
            ["width"] = "24",
          },
        },
        {
          name = "",
          x = 264,
          y = 288,
          width = 24,
          height = 24,
          type = "sprite",
          
          
          properties = { 
            ["flip"] = "true",
            ["height"] = "24",
            ["sheet"] = "images/sprites/hermittown/deadfishground.png",
            ["width"] = "24",
          },
        },
        {
          name = "",
          x = 120,
          y = 336,
          width = 24,
          height = 24,
          type = "sprite",
          
          
          properties = { 
            ["flip"] = "true",
            ["height"] = "24",
            ["sheet"] = "images/sprites/hermittown/deadfishground.png",
            ["width"] = "24",
          },
        },
        {
          name = "bone",
          x = 456,
          y = 312,
          width = 24,
          height = 24,
          type = "material",
          
          
          properties = { 
          },
        },
        {
          name = "bone",
          x = 240,
          y = 336,
          width = 24,
          height = 24,
          type = "material",
          
          
          properties = { 
          },
        },
        {
          name = "bone",
          x = 120,
          y = 312,
          width = 24,
          height = 24,
          type = "material",
          
          
          properties = { 
          },
        },
        {
          name = "bone",
          x = 360,
          y = 336,
          width = 24,
          height = 24,
          type = "material",
          
          
          properties = { 
          },
        },
        {
          name = "bone",
          x = 240,
          y = 264,
          width = 24,
          height = 24,
          type = "material",
          
          
          properties = { 
          },
        },
        {
          name = "",
          x = 384,
          y = 288,
          width = 24,
          height = 24,
          type = "sprite",
          
          
          properties = { 
            ["flip"] = "true",
            ["height"] = "24",
            ["sheet"] = "images/sprites/hermittown/brokenpot.png",
            ["width"] = "24",
          },
        },
        {
          name = "",
          x = 432,
          y = 336,
          width = 24,
          height = 24,
          type = "sprite",
          
          
          properties = { 
            ["height"] = "24",
            ["sheet"] = "images/sprites/hermittown/brokenpot.png",
            ["width"] = "24",
          },
        },
        {
          name = "",
          x = 456,
          y = 264,
          width = 24,
          height = 24,
          type = "sprite",
          
          
          properties = { 
            ["flip"] = "true",
            ["height"] = "24",
            ["sheet"] = "images/sprites/hermittown/brokenpot.png",
            ["width"] = "24",
          },
        },
        {
          name = "",
          x = 159,
          y = 327,
          width = 24,
          height = 24,
          type = "sprite",
          
          
          properties = { 
            ["height"] = "24",
            ["sheet"] = "images/sprites/hermittown/brokenpot.png",
            ["width"] = "24",
          },
        },
        {
          name = "",
          x = 390,
          y = 249,
          width = 24,
          height = 24,
          type = "sprite",
          
          
          properties = { 
            ["flip"] = "true",
            ["height"] = "24",
            ["sheet"] = "images/sprites/hermittown/brokenpot.png",
            ["width"] = "24",
          },
        },
        {
          name = "",
          x = 181,
          y = 252,
          width = 24,
          height = 24,
          type = "sprite",
          
          
          properties = { 
            ["flip"] = "true",
            ["height"] = "24",
            ["sheet"] = "images/sprites/hermittown/brokenpot.png",
            ["width"] = "24",
          },
        },
        {
          name = "",
          x = 335,
          y = 323,
          width = 24,
          height = 24,
          type = "sprite",
          
          
          properties = { 
            ["height"] = "24",
            ["sheet"] = "images/sprites/hermittown/brokenpot.png",
            ["width"] = "24",
          },
        },
      },
    },
  }
}