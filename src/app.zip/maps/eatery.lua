return {
  width = 31,
  height = 25,
  tilewidth = 24,
  tileheight = 24,
  orientation = "orthogonal",
  properties = { 
    ["blue"] = "250",
    ["green"] = "222",
    ["offset"] = "36",
    ["overworldName"] = "forest_3",
    ["red"] = "115",
    ["soundtrack"] = "abeds-town",
  },
  tilesets = { 
    {
      name = "forest",
      tilewidth = 24,
      tileheight = 24,
      spacing = 0,
      margin = 0,
      image = {
        source = "../images/tilesets/forest.png",
        width = "216",
        height = "504",
      },
      properties = { 
      },
    },
    {
      name = "collisions",
      tilewidth = 24,
      tileheight = 24,
      spacing = 0,
      margin = 0,
      image = {
        source = "../images/tilesets/collisions.png",
        width = "632",
        height = "512",
      },
      properties = { 
      },
    },
  },
  tilelayers = { 
    {
      name = "background",
      properties = { 
      },
      tiles = { false,false,false,false,false,false,false,{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},false,false,false,false,false,false,false,{id = 37,},{id = 37,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 77,},{id = 77,},{id = 77,},{id = 77,},{id = 77,},{id = 77,},{id = 77,},{id = 77,},{id = 77,},{id = 77,},{id = 77,},{id = 77,},{id = 77,},{id = 77,},{id = 77,},{id = 77,},{id = 77,},{id = 77,},{id = 77,},{id = 77,},{id = 77,},{id = 77,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 77,},{id = 77,},{id = 77,},{id = 77,},{id = 77,},{id = 77,},{id = 77,},{id = 77,},{id = 77,},{id = 77,},{id = 77,},{id = 77,},{id = 77,},{id = 77,},{id = 77,},{id = 77,},{id = 77,},{id = 77,},{id = 77,},{id = 77,},{id = 77,},{id = 77,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 77,},{id = 77,},{id = 77,},{id = 77,},{id = 77,},{id = 77,},{id = 77,},{id = 77,},{id = 77,},{id = 77,},{id = 77,},{id = 77,},{id = 77,},{id = 77,},{id = 77,},{id = 77,},{id = 77,},{id = 77,},{id = 77,},{id = 77,},{id = 77,},{id = 77,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 77,},{id = 77,},{id = 77,},{id = 77,},{id = 77,},{id = 77,},{id = 77,},{id = 77,},{id = 77,},{id = 77,},{id = 77,},{id = 77,},{id = 77,},{id = 77,},{id = 77,},{id = 77,},{id = 77,},{id = 77,},{id = 77,},{id = 77,},{id = 77,},{id = 77,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,}, },
    },
    {
      name = "foreground",
      properties = { 
      },
      tiles = { {id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},false,false,false,false,false,false,false,false,{id = 56,},{id = 56,},{id = 56,},{id = 56,},{id = 56,},{id = 56,},{id = 56,},{id = 56,},{id = 56,},{id = 56,},{id = 56,},{id = 56,},{id = 56,},{id = 56,},{id = 56,},{id = 56,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 40,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 93,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false, },
    },
    {
      name = "Tile Layer 5",
      properties = { 
      },
      tiles = { false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 56,},{id = 56,},{id = 56,},{id = 56,},{id = 56,},{id = 56,},{id = 56,},{id = 56,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 56,},{id = 56,},{id = 56,},{id = 56,},{id = 56,},{id = 56,},{id = 56,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 92,},{id = 85,},{id = 97,},false,false,false,false,false,false,false,false,false,{id = 92,},{id = 93,},{id = 97,},{id = 92,},{id = 93,},{id = 97,},false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 101,},{id = 70,},{id = 106,},false,false,false,false,false,false,false,false,false,{id = 101,},{id = 70,},{id = 106,},{id = 101,},{id = 70,},{id = 106,},false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 101,},{id = 70,},{id = 106,},false,false,false,false,false,false,false,false,false,{id = 101,},{id = 70,},{id = 106,},{id = 101,},{id = 70,},{id = 106,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false, },
    },
    {
      name = "collision",
      properties = { 
      },
      tiles = { false,{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},false,false,false,false,false,false,false,{id = 0,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 0,},false,false,false,false,false,false,false,{id = 0,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 0,},false,false,false,false,false,false,false,{id = 0,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 0,},false,false,false,false,false,false,false,{id = 0,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 0,},false,false,false,false,false,false,false,{id = 0,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 0,},false,false,false,false,false,false,false,{id = 0,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 0,},false,false,false,false,false,false,false,{id = 0,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 0,},false,false,false,false,false,false,false,{id = 0,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 0,},false,false,false,false,false,false,false,{id = 0,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 0,},false,false,false,false,false,false,false,{id = 0,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 0,},false,false,false,false,false,false,false,{id = 0,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 0,},false,false,false,false,false,false,false,{id = 0,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 0,},false,false,false,false,false,false,false,{id = 0,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 0,},false,false,false,false,false,false,false,{id = 0,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 0,},false,false,false,false,false,false,false,{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false, },
    },
  },
  objectgroups = { 
    ["floorspace"] = {
      name = "floorspace",
      properties = { 
      },
      objects = { 
        {
          name = "",
          x = 48,
          y = 264,
          width = 528,
          height = 96,
          type = "",
          
          
          properties = { 
            ["primary"] = "true",
          },
        },
        {
          name = "",
          x = 318,
          y = 319,
          width = 62,
          height = 15,
          type = "",
          
          
          properties = { 
            ["height"] = "15",
          },
        },
        {
          name = "",
          x = 197,
          y = 319,
          width = 62,
          height = 15,
          type = "",
          
          
          properties = { 
            ["height"] = "15",
          },
        },
        {
          name = "",
          x = 77,
          y = 318,
          width = 62,
          height = 15,
          type = "",
          
          
          properties = { 
            ["height"] = "15",
          },
        },
        {
          name = "",
          x = 409,
          y = 273,
          width = 22,
          height = 21,
          type = "",
          
          
          properties = { 
            ["height"] = "33",
          },
        },
        {
          name = "",
          x = 409,
          y = 285,
          width = 167,
          height = 10,
          type = "",
          
          
          properties = { 
            ["height"] = "33",
          },
        },
      },
    },
    ["nodes"] = {
      name = "nodes",
      properties = { 
      },
      objects = { 
        {
          name = "main",
          x = 168,
          y = 216,
          width = 24,
          height = 48,
          type = "door",
          
          
          properties = { 
            ["level"] = "hidden-town",
            ["sound"] = "false",
            ["to"] = "eatery",
          },
        },
        {
          name = "",
          x = 408,
          y = 216,
          width = 24,
          height = 79,
          type = "sprite",
          
          
          properties = { 
            ["depth"] = "50",
            ["height"] = "79",
            ["sheet"] = "images/sprites/town/barend.png",
            ["width"] = "24",
          },
        },
        {
          name = "",
          x = 408,
          y = 216,
          width = 168,
          height = 79,
          type = "sprite",
          
          
          properties = { 
            ["animation"] = "1-5,1",
            ["depth"] = "3",
            ["height"] = "79",
            ["mode"] = "bounce",
            ["sheet"] = "images/sprites/hermittown/Restaurant.png",
            ["width"] = "168",
          },
        },
        {
          name = "chef_wife",
          x = 408,
          y = 216,
          width = 48,
          height = 48,
          type = "npc",
          
          
          properties = { 
          },
        },
        {
          name = "",
          x = 72,
          y = 264,
          width = 72,
          height = 72,
          type = "sprite",
          
          
          properties = { 
            ["depth"] = "16",
            ["height"] = "72",
            ["sheet"] = "images/sprites/hermittown/table.png",
            ["width"] = "72",
          },
        },
        {
          name = "",
          x = 192,
          y = 264,
          width = 72,
          height = 72,
          type = "sprite",
          
          
          properties = { 
            ["depth"] = "16",
            ["height"] = "72",
            ["sheet"] = "images/sprites/hermittown/tableguy.png",
            ["width"] = "72",
          },
        },
        {
          name = "",
          x = 204,
          y = 264,
          width = 48,
          height = 48,
          type = "info",
          
          
          properties = { 
            ["info"] = "I don't talk to strangers| okay i'll talk|you know the chef's wife| her eye twitch gives me a bad feeling| i just try to ignore it| But...|i Think it's her husband| i think he beats her|or like steels from her| or| okay fine|i just like to talk to people|No one in this town likes talking to me|they say i talk too much|so now i just sit at this table all day and stare at my fish|sometimes i think i hear Voices|it's like somebody is saying..|Let me free|but you just think i'm crazy don't you?|everyone does|it dosen't hurt my feelings|i'm used to it|",
          },
        },
        {
          name = "kitchen",
          x = 456,
          y = 216,
          width = 24,
          height = 48,
          type = "door",
          
          
          properties = { 
            ["level"] = "kitchen",
            ["sound"] = "false",
            ["to"] = "main",
          },
        },
        {
          name = "",
          x = 528,
          y = 216,
          width = 24,
          height = 48,
          type = "info",
          
          
          properties = { 
            ["info"] = "Staff Only.",
          },
        },
        {
          name = "",
          x = 444,
          y = 192,
          width = 48,
          height = 24,
          type = "sprite",
          
          
          properties = { 
            ["height"] = "24",
            ["sheet"] = "images/sprites/hermittown/Kitchen.png",
            ["width"] = "48",
          },
        },
        {
          name = "",
          x = 528,
          y = 192,
          width = 24,
          height = 24,
          type = "sprite",
          
          
          properties = { 
            ["height"] = "24",
            ["sheet"] = "images/sprites/hermittown/StaffOnly.png",
            ["width"] = "24",
          },
        },
        {
          name = "staff",
          x = 336,
          y = 294,
          width = 24,
          height = 24,
          type = "key",
          
          
          properties = { 
          },
        },
        {
          name = "",
          x = 312,
          y = 264,
          width = 72,
          height = 72,
          type = "sprite",
          
          
          properties = { 
            ["depth"] = "16",
            ["height"] = "72",
            ["sheet"] = "images/sprites/hermittown/table.png",
            ["width"] = "72",
          },
        },
      },
    },
  }
}