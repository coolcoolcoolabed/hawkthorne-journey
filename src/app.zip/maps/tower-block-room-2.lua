return {
  width = 26,
  height = 21,
  tilewidth = 24,
  tileheight = 24,
  orientation = "orthogonal",
  properties = { 
    ["blue"] = "250",
    ["green"] = "222",
    ["offset"] = "36",
    ["overworldName"] = "forest_3",
    ["red"] = "115",
    ["soundtrack"] = "pocketful",
  },
  tilesets = { 
    {
      name = "forest",
      tilewidth = 24,
      tileheight = 24,
      spacing = 0,
      margin = 0,
      image = {
        source = "../images/tilesets/forest.png",
        width = "216",
        height = "504",
      },
      properties = { 
      },
    },
    {
      name = "collisions",
      tilewidth = 24,
      tileheight = 24,
      spacing = 0,
      margin = 0,
      image = {
        source = "../images/tilesets/collisions.png",
        width = "632",
        height = "512",
      },
      properties = { 
      },
    },
  },
  tilelayers = { 
    {
      name = "background",
      properties = { 
      },
      tiles = { {id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},false,false,false,false,{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},false,false,false,false,{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},false,false,false,false,{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},false,false,false,false,{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},false,false,false,false,{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},false,false,false,false,{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 36,},{id = 37,},{id = 37,},{id = 37,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 36,},{id = 37,},{id = 37,},{id = 37,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 36,},{id = 37,},{id = 37,},{id = 37,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 36,},{id = 37,},{id = 37,},{id = 37,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 36,},{id = 37,},{id = 37,},{id = 37,},{id = 40,},{id = 107,},{id = 107,},{id = 107,},{id = 107,},{id = 107,},{id = 107,},{id = 107,},{id = 107,},{id = 107,},{id = 107,},{id = 107,},{id = 107,},{id = 107,},{id = 107,},{id = 107,},{id = 107,},{id = 107,},{id = 107,},{id = 107,},{id = 107,},{id = 107,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 28,},{id = 28,},{id = 28,},{id = 28,},{id = 28,},{id = 28,},{id = 28,},{id = 28,},{id = 28,},{id = 28,},{id = 28,},{id = 37,},{id = 37,},{id = 37,},{id = 28,},{id = 28,},{id = 28,},{id = 28,},{id = 28,},{id = 28,},{id = 28,},{id = 28,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,}, },
    },
    {
      name = "foreground",
      properties = { 
      },
      tiles = { false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 38,},{id = 56,},{id = 56,},{id = 56,},{id = 56,},{id = 56,},{id = 56,},{id = 56,},{id = 56,},{id = 56,},{id = 56,},{id = 56,},{id = 56,},{id = 56,},{id = 56,},{id = 56,},{id = 56,},{id = 56,},{id = 56,},{id = 56,},{id = 56,},{id = 56,},{id = 56,},{id = 56,},{id = 56,},{id = 56,},{id = 38,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 38,},false,false,false,false,false,false,false,{id = 70,},false,false,false,false,{id = 92,},{id = 96,},{id = 97,},false,false,{id = 70,},false,false,false,false,false,false,false,{id = 38,},false,false,false,false,false,false,false,false,false,{id = 40,},false,false,{id = 101,},{id = 77,},{id = 106,},false,false,false,false,false,false,false,false,false,false,{id = 38,},false,false,false,false,false,false,false,false,false,false,false,false,{id = 101,},{id = 77,},{id = 106,},false,false,false,false,false,false,false,false,false,false,{id = 38,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false, },
    },
    {
      name = "Tile Layer 5",
      properties = { 
      },
      tiles = { false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 49,},{id = 50,},{id = 49,},{id = 50,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 49,},{id = 50,},{id = 49,},{id = 50,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 49,},{id = 50,},{id = 49,},{id = 50,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 49,},{id = 50,},{id = 49,},{id = 50,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 49,},{id = 50,},{id = 49,},{id = 50,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 56,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 56,},false,false,false,false,false,{id = 85,},false,false,false,{id = 56,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 162,},{id = 162,},{id = 162,},{id = 162,},{id = 162,},{id = 162,},{id = 162,},{id = 162,},{id = 162,},{id = 162,},{id = 162,},{id = 162,},{id = 162,},{id = 162,},{id = 162,},{id = 162,},{id = 162,},{id = 162,},{id = 162,},{id = 162,},{id = 162,},false,false,false,false,false,false,false,false,false,false,false,{id = 37,},{id = 37,},false,false,false,false,{id = 37,},{id = 37,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false, },
    },
    {
      name = "collision",
      properties = { 
      },
      tiles = { false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 21,},{id = 21,},{id = 21,},{id = 21,},{id = 21,},{id = 21,},{id = 21,},{id = 21,},{id = 21,},{id = 21,},{id = 21,},{id = 21,},{id = 21,},{id = 21,},{id = 21,},{id = 21,},{id = 21,},{id = 21,},{id = 21,},{id = 21,},{id = 21,},false,false,false,false,{id = 0,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 0,},false,false,false,{id = 0,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 0,},false,false,false,{id = 0,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 0,},false,false,false,{id = 0,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 0,},false,false,false,{id = 0,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 0,},false,false,false,{id = 0,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 0,},false,false,false,{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false, },
    },
  },
  objectgroups = { 
    ["floorspace"] = {
      name = "floorspace",
      properties = { 
      },
      objects = { 
        {
          name = "",
          x = 24,
          y = 264,
          width = 504,
          height = 24,
          type = "",
          
          
          properties = { 
            ["primary"] = "true",
          },
        },
        {
          name = "",
          x = 54,
          y = 279,
          width = 0,
          height = 0,
          type = "",
          
          polygon = { 
            { x = 0, y = 0 },
            { x = -1, y = -24 },
            { x = 77, y = -23 },
            { x = 99, y = -1 },
          },
          properties = { 
            ["height"] = "24",
          },
        },
      },
    },
    ["nodes"] = {
      name = "nodes",
      properties = { 
      },
      objects = { 
        {
          name = "main",
          x = 336,
          y = 216,
          width = 24,
          height = 48,
          type = "door",
          
          
          properties = { 
            ["level"] = "tower-block",
            ["sound"] = "false",
            ["to"] = "tower-block-room-2",
          },
        },
        {
          name = "rock",
          x = 173,
          y = 255,
          width = 24,
          height = 24,
          type = "material",
          
          
          properties = { 
          },
        },
        {
          name = "",
          x = 48,
          y = 240,
          width = 120,
          height = 48,
          type = "sprite",
          
          
          properties = { 
            ["depth"] = "18",
            ["flip"] = "true",
            ["height"] = "47",
            ["sheet"] = "images/sprites/town/bed.png",
            ["width"] = "95",
          },
        },
        {
          name = "",
          x = 24,
          y = 216,
          width = 24,
          height = 48,
          type = "sprite",
          
          
          properties = { 
            ["flip"] = "true",
            ["height"] = "48",
            ["sheet"] = "images/sprites/town/bed_headboard.png",
            ["width"] = "24",
          },
        },
        {
          name = "",
          x = 241,
          y = 228,
          width = 24,
          height = 48,
          type = "sprite",
          
          
          properties = { 
            ["height"] = "48",
            ["sheet"] = "images/sprites/hermittown/guide3.png",
            ["width"] = "41",
          },
        },
        {
          name = "banana",
          x = 366,
          y = 254,
          width = 24,
          height = 24,
          type = "material",
          
          
          properties = { 
          },
        },
        {
          name = "",
          x = 241,
          y = 228,
          width = 24,
          height = 48,
          type = "info",
          
          
          properties = { 
            ["info"] = "Hello| You may have met my brothers| they will tell you about our town",
          },
        },
      },
    },
  }
}