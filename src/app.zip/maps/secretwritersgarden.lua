return {
  width = 25,
  height = 14,
  tilewidth = 24,
  tileheight = 24,
  orientation = "orthogonal",
  properties = { 
    ["autosave"] = "false",
    ["soundtrack"] = "lovesoalike",
  },
  tilesets = { 
    {
      name = "secretgarden",
      tilewidth = 24,
      tileheight = 24,
      spacing = 0,
      margin = 0,
      image = {
        source = "../images/tilesets/secretgarden.png",
        width = "288",
        height = "216",
      },
      properties = { 
      },
    },
    {
      name = "collisions",
      tilewidth = 24,
      tileheight = 24,
      spacing = 0,
      margin = 0,
      image = {
        source = "../images/tilesets/collisions.png",
        width = "632",
        height = "512",
      },
      properties = { 
      },
    },
  },
  tilelayers = { 
    {
      name = "bg",
      properties = { 
      },
      tiles = { {id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 36,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 36,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 36,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 36,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 36,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 36,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 36,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 36,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 36,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 36,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 36, flipHorizontal = true,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 36,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 36,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 36,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 36,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 36,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},false,false,false,false,false,false,false,false,{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,},{id = 14,}, },
    },
    {
      name = "pipe",
      properties = { 
      },
      tiles = { false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 22,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 11, flipHorizontal = true, flipVertical = true,},{id = 10, flipVertical = true,},{id = 10, flipVertical = true,},{id = 10, flipVertical = true,},{id = 10, flipVertical = true,},{id = 10, flipVertical = true,},{id = 10, flipVertical = true,},{id = 10, flipVertical = true,},{id = 10, flipVertical = true,},{id = 10, flipVertical = true,},{id = 10, flipVertical = true,},{id = 10, flipVertical = true,},{id = 10, flipVertical = true,},{id = 10, flipVertical = true,},{id = 10, flipVertical = true,},{id = 10, flipVertical = true,},{id = 23, flipDiagonal = true,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 10, flipVertical = true, flipDiagonal = true,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 10, flipVertical = true, flipDiagonal = true,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 10, flipVertical = true, flipDiagonal = true,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 10, flipVertical = true, flipDiagonal = true,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 10, flipVertical = true, flipDiagonal = true,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 10, flipVertical = true, flipDiagonal = true,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 10, flipVertical = true, flipDiagonal = true,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 10, flipVertical = true, flipDiagonal = true,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 10, flipVertical = true, flipDiagonal = true,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false, },
    },
    {
      name = "ground",
      properties = { 
      },
      tiles = { false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 5,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 17,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 2,},{id = 2,},{id = 2,},{id = 2,},{id = 2,},{id = 2,},{id = 2,},{id = 2,},{id = 2,},{id = 2,},{id = 2,},{id = 2,},{id = 2,},{id = 2,},{id = 2,},{id = 2,},{id = 2,},{id = 2,},{id = 2,},{id = 2,},{id = 2,},{id = 2,},{id = 2,},{id = 2,},{id = 2,}, },
    },
    {
      name = "hedge",
      properties = { 
      },
      tiles = { false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 25, flipHorizontal = true, flipDiagonal = true,},{id = 13, flipHorizontal = true, flipDiagonal = true,},{id = 13, flipDiagonal = true,},{id = 13, flipDiagonal = true,},{id = 13, flipHorizontal = true, flipDiagonal = true,},{id = 13, flipDiagonal = true,},{id = 13, flipDiagonal = true,},{id = 13, flipHorizontal = true, flipDiagonal = true,},{id = 13, flipHorizontal = true, flipDiagonal = true,},{id = 25, flipDiagonal = true,},false,false,false,{id = 25, flipHorizontal = true, flipDiagonal = true,},{id = 13, flipHorizontal = true, flipDiagonal = true,},{id = 13, flipDiagonal = true,},{id = 13, flipDiagonal = true,},{id = 13, flipHorizontal = true, flipDiagonal = true,},{id = 13, flipDiagonal = true,},{id = 13, flipDiagonal = true,},{id = 13, flipHorizontal = true, flipDiagonal = true,},{id = 13, flipHorizontal = true, flipDiagonal = true,},{id = 25, flipDiagonal = true,},false,false,{id = 25, flipHorizontal = true, flipVertical = true, flipDiagonal = true,},{id = 1,},{id = 1,},{id = 1,},{id = 1,},{id = 1,},{id = 1,},{id = 1,},{id = 1,},{id = 25, flipVertical = true, flipDiagonal = true,},false,false,false,{id = 25, flipHorizontal = true, flipVertical = true, flipDiagonal = true,},{id = 1,},{id = 1,},{id = 1,},{id = 1,},{id = 1,},{id = 1,},{id = 1,},{id = 1,},{id = 25, flipVertical = true, flipDiagonal = true,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false, },
    },
    {
      name = "ledges",
      properties = { 
      },
      tiles = { false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 3,},{id = 4,},{id = 4,},{id = 4,},{id = 4,},{id = 4,},{id = 4,},{id = 4,},{id = 4,},{id = 3, flipHorizontal = true,},false,false,false,{id = 3,},{id = 4,},{id = 4,},{id = 4,},{id = 4,},{id = 4,},{id = 4,},{id = 4,},{id = 4,},{id = 3, flipHorizontal = true,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false, },
    },
    {
      name = "board",
      properties = { 
      },
      tiles = { false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 15,},{id = 16,},{id = 16,},{id = 16,},{id = 16,},{id = 16,},{id = 16,},{id = 16, flipHorizontal = true,},{id = 15, flipHorizontal = true,},false,false,false,false,false,false,false,false,false,false,false,{id = 15,},{id = 16,},{id = 27, flipHorizontal = true, flipDiagonal = true,},{id = 15, flipHorizontal = true, flipDiagonal = true,},false,{id = 27,},{id = 28,},{id = 28,},{id = 28,},{id = 28,},{id = 28,},{id = 28,},{id = 28, flipHorizontal = true,},{id = 27, flipHorizontal = true,},false,false,false,false,false,false,false,false,false,false,false,{id = 27, flipVertical = true,},{id = 28, flipVertical = true,},{id = 28, flipHorizontal = true, flipVertical = true,},{id = 27, flipHorizontal = true, flipVertical = true,},false,{id = 27, flipVertical = true,},{id = 28,},{id = 28,},{id = 28,},{id = 28,},{id = 28,},{id = 28,},{id = 28, flipHorizontal = true, flipVertical = true,},{id = 27, flipHorizontal = true, flipVertical = true,},false,false,false,false,false,false,false,false,false,false,false,{id = 15, flipVertical = true,},{id = 16, flipVertical = true,},{id = 16, flipHorizontal = true, flipVertical = true,},{id = 15, flipHorizontal = true, flipVertical = true,},false,{id = 15, flipVertical = true,},{id = 16, flipVertical = true,},{id = 16, flipVertical = true,},{id = 16, flipVertical = true,},{id = 16, flipVertical = true,},{id = 16, flipVertical = true,},{id = 16, flipVertical = true,},{id = 16, flipHorizontal = true, flipVertical = true,},{id = 15, flipHorizontal = true, flipVertical = true,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false, },
    },
    {
      name = "trees",
      properties = { 
      },
      tiles = { false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 8,},{id = 9,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 8,},{id = 9,},{id = 20,},{id = 21,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 20,},{id = 21,},{id = 32,},{id = 33,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 32,},{id = 33,},{id = 44,},{id = 45,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 44,},{id = 45,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false, },
    },
    {
      name = "writing",
      properties = { 
      },
      tiles = { false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 38,},{id = 41,},{id = 40,},{id = 41,},false,{id = 51,},{id = 52,},{id = 52, flipHorizontal = true,},{id = 51, flipHorizontal = true,},false,false,false,false,false,false,false,false,false,false,false,false,{id = 68,},{id = 69,},false,false,false,{id = 26,},{id = 26, flipHorizontal = true,},{id = 39,},{id = 50,},{id = 63,},{id = 64,},{id = 64, flipHorizontal = true,},{id = 63, flipHorizontal = true,},false,false,false,{id = 6,},{id = 7,},false,false,false,false,false,false,false,{id = 80,},{id = 81,},false,false,false,{id = 26, flipVertical = true,},{id = 26, flipHorizontal = true, flipVertical = true,},false,false,{id = 53,},{id = 64, flipHorizontal = true, flipVertical = true,},{id = 63, flipHorizontal = true, flipVertical = true,},false,false,false,false,{id = 18,},{id = 19,},false,false,false,false,false,false,false,{id = 92,},{id = 93,},false,false,false,{id = 30,},{id = 38,},{id = 40, flipHorizontal = true, flipVertical = true,},false,{id = 31,},{id = 52, flipHorizontal = true, flipVertical = true,},{id = 51, flipHorizontal = true, flipVertical = true,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 42,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 48,},{id = 49,},false,false,false,false,false,false,false,false,false,false,false,false,{id = 43, flipHorizontal = true,},{id = 37,},{id = 37, flipHorizontal = true,},false,false,false,false,false,false,false,false,{id = 60,},{id = 61,},false,false,false,false,false,false,{id = 43,},false,false,false,false,false,false,false,false,{id = 55, flipHorizontal = true, flipVertical = true,},false,false,false,{id = 55, flipVertical = true, flipDiagonal = true,},false,false,false,{id = 43, flipHorizontal = true,},false,false,{id = 55, flipHorizontal = true, flipVertical = true, flipDiagonal = true,},false,false,false,false,false,false,false,false,{id = 55, flipVertical = true,}, },
    },
    {
      name = "tables",
      properties = { 
        ["foreground"] = "true",
      },
      tiles = { false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 57,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 34,},{id = 35,},{id = 58,},{id = 35, flipHorizontal = true,},{id = 34, flipHorizontal = true,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 46,},{id = 47,},false,{id = 47, flipHorizontal = true,},{id = 46, flipHorizontal = true,},false,false,false, },
    },
    {
      name = "writers",
      properties = { 
      },
      tiles = { false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 72,},{id = 73,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 84,},{id = 85,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 88,},false,false,false,false,{id = 96,},{id = 97,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false, },
    },
    {
      name = "writers2",
      properties = { 
        ["foreground"] = "true",
      },
      tiles = { false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 74,},{id = 75,},false,false,false,false,false,false,false,{id = 65,},{id = 66,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 86,},{id = 87,},false,false,false,false,false,false,false,{id = 77,},{id = 78,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 98,},{id = 99,},false,false,false,false,false,false,false,{id = 89,},{id = 90,},false,false,false,false,false,false, },
    },
    {
      name = "collision",
      properties = { 
      },
      tiles = { false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 26,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 26,},{id = 26,},{id = 26,},{id = 26,},{id = 26,},{id = 26,},{id = 26,},{id = 26,},{id = 26,},{id = 26,},{id = 26,},{id = 26,},{id = 26,},{id = 26,},{id = 26,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 49,},{id = 48,},{id = 49,},{id = 48,},{id = 47,},{id = 47,},{id = 47,},{id = 47,},{id = 47,},{id = 47,},{id = 47,},false,false,false,{id = 47,},{id = 47,},{id = 47,},{id = 47,},{id = 51,},{id = 26,},{id = 50,},{id = 47,},{id = 47,},{id = 47,},false,{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,}, },
    },
  },
  objectgroups = { 
    ["nodes"] = {
      name = "nodes",
      properties = { 
      },
      objects = { 
        {
          name = "",
          x = 192,
          y = 0,
          width = 24,
          height = 48,
          type = "h_sprite",
          
          
          properties = { 
            ["animation"] = "1-4,1",
            ["height"] = "48",
            ["sheet"] = "images/liquid/fountaindrain.png",
            ["width"] = "24",
          },
        },
        {
          name = "pipe",
          x = 262,
          y = -24,
          width = 24,
          height = 25,
          type = "door",
          
          
          properties = { 
          },
        },
        {
          name = "main",
          x = 288,
          y = 264,
          width = 24,
          height = 48,
          type = "door",
          
          
          properties = { 
            ["level"] = "greendale-exterior",
            ["to"] = "writersexit",
          },
        },
        {
          name = "",
          x = 55,
          y = 261,
          width = 29,
          height = 55,
          type = "info",
          
          
          properties = { 
            ["info"] = "I'm telling you the same thing I told that pathological red fox:|You can't rub my head for good luck.",
          },
        },
        {
          name = "",
          x = 203,
          y = 265,
          width = 26,
          height = 52,
          type = "info",
          
          
          properties = { 
            ["info"] = "Let's see, we'll do this, and then this and that...|Oooh, that'll be a good twist...|(It appears he's paying more attention to the board than to you)",
          },
        },
        {
          name = "",
          x = 527,
          y = 271,
          width = 26,
          height = 43,
          type = "info",
          
          
          properties = { 
            ["info"] = "Somebody left their hoodie here.|Huh? There's a note in the pocket...|It reads 'Gone to visit the Family...'",
          },
        },
        {
          name = "",
          x = 416,
          y = 264,
          width = 29,
          height = 54,
          type = "info",
          
          
          properties = { 
            ["info"] = "It's good to be home.",
          },
        },
      },
    },
  }
}