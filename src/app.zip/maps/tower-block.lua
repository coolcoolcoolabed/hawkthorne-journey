return {
  width = 26,
  height = 21,
  tilewidth = 24,
  tileheight = 24,
  orientation = "orthogonal",
  properties = { 
    ["blue"] = "250",
    ["green"] = "222",
    ["offset"] = "36",
    ["overworldName"] = "forest_3",
    ["red"] = "115",
    ["soundtrack"] = "forest-2",
  },
  tilesets = { 
    {
      name = "forest",
      tilewidth = 24,
      tileheight = 24,
      spacing = 0,
      margin = 0,
      image = {
        source = "../images/tilesets/forest.png",
        width = "216",
        height = "504",
      },
      properties = { 
      },
    },
    {
      name = "collisions",
      tilewidth = 24,
      tileheight = 24,
      spacing = 0,
      margin = 0,
      image = {
        source = "../images/tilesets/collisions.png",
        width = "632",
        height = "512",
      },
      properties = { 
      },
    },
  },
  tilelayers = { 
    {
      name = "background",
      properties = { 
      },
      tiles = { {id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},false,false,false,false,{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},false,false,false,false,{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},false,false,false,false,{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},false,false,false,false,{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},false,false,false,false,{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 49,},{id = 50,},false,false,false,false,{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 36,},{id = 37,},{id = 37,},{id = 37,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 36,},{id = 37,},{id = 37,},{id = 37,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 36,},{id = 37,},{id = 37,},{id = 37,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 36,},{id = 37,},{id = 37,},{id = 37,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 36,},{id = 37,},{id = 37,},{id = 37,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 40,},{id = 36,},{id = 37,},{id = 37,},{id = 37,},{id = 28,},{id = 28,},{id = 28,},{id = 28,},{id = 28,},{id = 28,},{id = 28,},{id = 28,},{id = 28,},{id = 28,},{id = 28,},{id = 28,},{id = 28,},{id = 28,},{id = 28,},{id = 28,},{id = 28,},{id = 28,},{id = 28,},{id = 28,},{id = 28,},{id = 28,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,},{id = 37,}, },
    },
    {
      name = "foreground",
      properties = { 
      },
      tiles = { false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 38,},{id = 56,},{id = 56,},{id = 56,},{id = 56,},{id = 56,},{id = 56,},{id = 56,},{id = 56,},{id = 56,},{id = 56,},{id = 56,},{id = 56,},{id = 56,},{id = 56,},{id = 56,},{id = 56,},{id = 56,},{id = 56,},{id = 56,},{id = 56,},{id = 56,},{id = 56,},{id = 56,},{id = 56,},{id = 56,},{id = 38,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 38,},false,false,{id = 92,},{id = 93,},{id = 96,},{id = 97,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 42,},false,false,false,false,{id = 38,},false,false,{id = 101,},{id = 77,},{id = 77,},{id = 106,},false,false,false,false,{id = 92,},{id = 96,},{id = 96,},{id = 96,},{id = 96,},{id = 96,},{id = 97,},false,false,{id = 42,},{id = 42,},false,false,false,false,{id = 38,},false,false,{id = 101,},{id = 77,},{id = 77,},{id = 106,},false,false,false,false,false,{id = 77,},{id = 106,},{id = 77,},{id = 106,},{id = 77,},{id = 106,},false,{id = 42,},{id = 42,},{id = 42,},false,false,false,false,{id = 38,},false,false,{id = 101,},{id = 77,},{id = 77,},{id = 106,},false,false,false,false,false,{id = 77,},{id = 106,},{id = 77,},{id = 106,},{id = 77,},{id = 106,},{id = 42,},{id = 42,},{id = 42,},{id = 42,},false,false,false,false,{id = 37,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false, },
    },
    {
      name = "Tile Layer 5",
      properties = { 
      },
      tiles = { false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 49,},{id = 50,},{id = 49,},{id = 50,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 49,},{id = 50,},{id = 49,},{id = 50,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 49,},{id = 50,},{id = 49,},{id = 50,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 49,},{id = 50,},{id = 49,},{id = 50,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 49,},{id = 50,},{id = 49,},{id = 50,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 49,},{id = 50,},{id = 49,},{id = 50,},{id = 56,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 85,},false,{id = 85,},false,{id = 85,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 128,},false,false,{id = 101,},false,{id = 101,},false,{id = 101,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 146,},false,false,{id = 101,},false,{id = 101,},false,{id = 101,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false, },
    },
    {
      name = "collision",
      properties = { 
      },
      tiles = { false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 21,},{id = 21,},{id = 21,},{id = 21,},{id = 21,},{id = 21,},{id = 21,},{id = 21,},{id = 21,},{id = 21,},{id = 21,},{id = 21,},{id = 21,},{id = 21,},{id = 21,},{id = 21,},{id = 21,},{id = 21,},{id = 21,},{id = 21,},{id = 21,},false,false,false,false,{id = 0,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 0,},false,false,false,{id = 0,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 0,},false,false,false,{id = 0,},false,false,{id = 26,},{id = 26,},{id = 26,},{id = 26,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 26,},{id = 0,},false,false,false,{id = 0,},false,false,false,false,false,false,false,false,false,false,{id = 26,},{id = 26,},{id = 26,},{id = 26,},{id = 26,},{id = 26,},{id = 26,},false,false,{id = 26,},{id = 26,},{id = 0,},false,false,false,{id = 0,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 26,},{id = 26,},{id = 26,},{id = 0,},false,false,false,{id = 0,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,{id = 26,},{id = 26,},{id = 26,},{id = 26,},{id = 0,},false,false,false,{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},{id = 0,},false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false, },
    },
  },
  objectgroups = { 
    ["nodes"] = {
      name = "nodes",
      properties = { 
      },
      objects = { 
        {
          name = "stick",
          x = 432,
          y = 240,
          width = 24,
          height = 24,
          type = "material",
          
          
          properties = { 
          },
        },
        {
          name = "main",
          x = 96,
          y = 216,
          width = 48,
          height = 72,
          type = "door",
          
          
          properties = { 
            ["level"] = "hidden-town",
            ["sound"] = "false",
            ["to"] = "tower-block",
          },
        },
        {
          name = "stick",
          x = 504,
          y = 264,
          width = 24,
          height = 24,
          type = "material",
          
          
          properties = { 
          },
        },
        {
          name = "stick",
          x = 480,
          y = 192,
          width = 24,
          height = 24,
          type = "material",
          
          
          properties = { 
          },
        },
        {
          name = "rock",
          x = 144,
          y = 264,
          width = 24,
          height = 24,
          type = "material",
          
          
          properties = { 
          },
        },
        {
          name = "",
          x = 216,
          y = 240,
          width = 24,
          height = 48,
          type = "sprite",
          
          
          properties = { 
            ["height"] = "48",
            ["sheet"] = "images/sprites/hermittown/guide2.png",
            ["width"] = "41",
          },
        },
        {
          name = "",
          x = 216,
          y = 240,
          width = 24,
          height = 48,
          type = "info",
          
          
          properties = { 
            ["info"] = "this is the tower block| the doors take you to the rooms",
          },
        },
        {
          name = "tower-block-room-1",
          x = 288,
          y = 240,
          width = 24,
          height = 48,
          type = "door",
          
          
          properties = { 
            ["level"] = "tower-block-room-1",
            ["sound"] = "false",
            ["to"] = "main",
          },
        },
        {
          name = "tower-block-room-2",
          x = 336,
          y = 241,
          width = 24,
          height = 48,
          type = "door",
          
          
          properties = { 
            ["level"] = "tower-block-room-2",
            ["sound"] = "false",
            ["to"] = "main",
          },
        },
        {
          name = "tower-block-room-3",
          x = 384,
          y = 240,
          width = 24,
          height = 48,
          type = "door",
          
          
          properties = { 
            ["level"] = "tower-block-room-3",
            ["sound"] = "false",
            ["to"] = "main",
          },
        },
        {
          name = "",
          x = 108,
          y = 192,
          width = 24,
          height = 24,
          type = "sprite",
          
          
          properties = { 
            ["height"] = "24",
            ["sheet"] = "images/sprites/hermittown/arrow.png",
            ["width"] = "24",
          },
        },
      },
    },
  }
}