local app = require 'hawk/application'
return app('config.json')
