# Auto-updating

These steps assume it's time for an update

## Windows

- Download the four needed files for the release into the working directory
  under new names
  - new_SDL.dll
  - new_OpenAL32.dll
  - new_DeVIL.dll
  - new_hawkthorne.exe
- Move the current items to a different name
  - old_SDL.dll
  - old_OpenAL32.dll
  - old_DeVIL.dll
  - old_hawkthorne.exe
- Now move all the new items to their expected location
- And relaunch the game

## OSX 

- Download the latest zipped app
- Unzip the app into the save game directory
- Remove the current app
- Move the freshly downloaded app to the old location
- Open it up

