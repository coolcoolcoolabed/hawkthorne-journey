--table of item,amount,cost

return {
  weapons = {
    {"throwingaxe",10,10},
    {"mallet",2,400},
    {"longsword",1,350},
    {"mace",1,550},
    {"battleaxe",2,550},
    {"boneclub",6,70},
    {"bow",3,200},
    {"arrow",30,6},
    {"crimson_sword",1,450},
  },
  materials = {
    {"leaf",10,55},
    {"stone",10,60},
    {"stick",15,30},
    {"bone",30,20},
    {"ember",20,65},
    {"banana",20,50},
    {"fire",5,120},
    {"peanut",30,65},
    {"eye",30,62},
    {"arm",30,60},
    {"frog",30,45},
  },
  consumables = {
    {"red_potion",10,80},
    {"white_potion",5,120},
    {"watermelon",2,135},
    {"tacomeat",1,470},
  },
  misc = {
    {"lightning",4,300},
    {"ghost_pepper",4,200}
  }
}
