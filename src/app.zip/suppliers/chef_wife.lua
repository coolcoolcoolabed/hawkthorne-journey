--table of item,amount,cost

return {
  weapons = {
    {"cherrypopper",1,500},
  },
  materials = {
    {"banana",3,50},
    {"bubblgum",1,25},
    {"fries",5,35},
    {"peanut",7,70},
    {"mushroom",20,30},
    {"toast",20,32},
    {"bone",20,50},
    {"pancake",10,80},
  },
  consumables = {
    {"red_potion",5,80},    {"alcohol",10,50},
    {"baggle",1,50},    {"crabdip",25,10},    {"catheadsoup",5,75},    {"chickenfinger",2,200},    {"chickenfinger",27,30},    {"pickled_bull_testicles",1,25},    {"watermelon",4,10}
  }
}
