--table of item,amount,cost

return {
  weapons = {
    {"throwingknife",25,10},
    {"throwingaxe",30,15},
    {"mallet",2,400},
    {"torch",3,200},
    {"sword",3,175},
    {"longsword",1,350},
    {"mace",1,600},
    {"battleaxe",2,500},
    {"boneclub",6,75},
    {"crimson_sword",2,2500},
    {"bow",3,200},
    {"arrow",50,5},
  },
  materials = {
    {"mushroom",20,30},
    {"duck",20,34},
    {"banana",30,45},
    {"peanut",30,40},
    {"star",30,85},
    {"arm",30,60},
  },
  consumables = {
    {"red_potion",5,100},
    {"white_potion",3,140},
    {"pink_potion",2,300},
    {"orange_potion",2,200},
  },
  misc = {
    {"lightning",3,350}
  }
}
