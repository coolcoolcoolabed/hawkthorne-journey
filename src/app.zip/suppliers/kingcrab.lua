--table of item,amount,cost

return {
  weapons = {

    {"cherrypopper",1,2175},

    {"bow",3,200},
    {"arrow",24,5},
  },
  materials = {
    {"mushroom",2,30},
    {"duck",1,34},
    {"banana",6,45},
    {"peanut",4,40},
    {"star",3,85},
    {"arm",13,60},
  },
  consumables = {
    {"red_potion",1,100},
    {"white_potion",1,140},
    {"pink_potion",2,300},

  },
  misc = {    {"rainbow_lightning",1,750}
  }
}
