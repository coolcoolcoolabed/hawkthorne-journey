--table of item,amount,cost

return {
  weapons = {
    {"throwingknife",15,6},
    {"throwingaxe",12,8},
    {"torch",3,200},
    {"sword",3,180},
    {"longsword",1,380},
    {"mace",1,580},
    {"switch",6,80},
    {"bow",3,230},
    {"arrow",25,8},
  },
  materials = {
    {"leaf",30,30},
    {"rock",30,15},
    {"stone",30,35},
    {"stick",30,15},
    {"mushroom",20,30},
    {"duck",20,32},
    {"bone",20,50},
    {"banana",10,50},
    {"peanut",10,75},
    {"ember",10,80},
  },
  consumables = {
    {"red_potion",5,80},
  },
  misc = {
    {"lightning",3,350}
  }
}
