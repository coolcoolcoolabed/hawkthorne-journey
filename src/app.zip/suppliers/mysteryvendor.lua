--table of item,amount,cost

return {
  weapons = {
    {"blueskyspecial",1,10000},
  },
  materials = {
    {"fries",99,25},
    {"pancake",99,100},
    {"banana",99,100},
    {"toast",99,100},
    {"carkeys",99,100},
    {"bubblgum",99,100},
  },
  keys = {
    {"ladiesroom",1,1000},
  }
}
