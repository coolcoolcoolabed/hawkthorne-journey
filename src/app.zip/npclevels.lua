-- npc =  {affection, respect, trust, married}

return {
  blacksmith = {0, 0, 0, true},
  hilda = {0, 0, 0, false},
  jerry = {0, 0, 0, false},
  leslie = {0, 0, 0, false},
  oldman = {0, 0, 0, false},
  juanita = {0, 0, 0, false},
}